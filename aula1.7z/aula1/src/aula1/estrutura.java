package aula1;

public class estrutura {

	public static void main(String[] args) {
		
		int[][] a = new int[10][10];
		
	 
        for (int l = 0; l < a.length; l++){  
           System.out.println();
            for (int c = 0; c < a.length; c++) {  
            	a[l][c] = 0;
            	
            }  
        }
    	System.out.println("Matriz Completa: "); 
        for (int l = 0; l < a.length; l++){  
            System.out.println();
             for (int c = 0; c < a.length; c++) {  
             	System.out.print(a[l][c] +" ");
             	
             	
             }  
         }
        System.out.println("");
        
            System.out.println("Diagonal primaria: ");  
            for (int l1 = 0; l1 < a.length; l1++){ 
            System.out.println();
                for (int c1 = 0; c1 < a.length; c1++) {  
                	if (l1==c1) {
						System.out.print(a[l1][c1]);
					} else {
						System.out.print("* ");
					}
                }  

            }
            
            System.out.println("");
            
            System.out.println("Diagonal secundaria: ");  
            for (int l1 = 0; l1 < a.length; l1++){ 
            System.out.println();
                for (int c1 = 0; c1 < a.length; c1++) {  
                	if (l1 + c1 == 9) {
						System.out.print(a[l1][c1]);
					} else {
						System.out.print("* ");
					}
                }  

            }
            
            System.out.println("");
            
            System.out.println("Triangulo Superior: ");  
            for (int l1 = 0; l1 < a.length; l1++){ 
            System.out.println();
                for (int c1 = 0; c1 < a.length; c1++) {  
                	if (l1 < c1) {
						System.out.print(a[l1][c1]);
					} else {
						System.out.print("* ");
					}
                }  

            }
            
            System.out.println("");
            
            System.out.println("Triangulo Inferior: ");  
            for (int l1 = 0; l1 < a.length; l1++){ 
            System.out.println();
                for (int c1 = 0; c1 < a.length; c1++) {  
                	if (l1 > c1) {
						System.out.print(a[l1][c1]);
					} else {
						System.out.print("* ");
					}
                }  

            }
            

            
            
            }
            
            }


	