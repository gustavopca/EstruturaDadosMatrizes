package multiplicacao;
import java.util.Scanner;

public class multiplicacao {

		public static void main(String[] args) {
			
			int [][]a = new int [10][10];
			int [][]b = new int [10][10];
			int [][]result = new int [10][10];
			
			for (int i = 0; i < result.length; i++) {
				for (int j = 0; j < result.length; j++) {
					a[i][j] = j;
					result[i][j] = 0;
				}
			}
			
			for (int i = 0; i < result.length; i++) {
				for (int j = 0; j < result.length; j++) {
					b[i][j] = j;
				}
			}
			
			
			for (int i = 0; i < result.length; i++) {
				for (int j = 0; j < result.length; j++) {
					for (int j2 = 0; j2 < result.length; j2++) {
						result[i][j] += a[i][j]*b[j][j2];
					}
				}
			}
			
			for (int i = 0; i < result.length; i++) {
				for (int j = 0; j < result.length; j++) {
					System.out.print(result[i][j]+" ");
				}
				System.out.println();
			}
		}
}

		


